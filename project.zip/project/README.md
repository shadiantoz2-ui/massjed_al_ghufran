# Quran & Hadith Tracker (Lovable + TanStack Start + Supabase)

هذا المستودع تم تنظيمه من الملفات التي رفعتها بحيث يطابق بنية مشروع
[TanStack Start](https://tanstack.com/start) المتصل بـ Supabase عبر Lovable.

## ⚠️ تنبيه مهم قبل الرفع على GitHub

الملفات التي زوّدتني بها هي **جزء فقط** من المشروع (ملفات مساعدة/backend/بيانات)،
وليست كل المشروع. لكي يعمل المشروع فعليًا بعد رفعه، ينقصك من واجهة Lovable الأصلية:

- ملفات الصفحات/الراوتس الفعلية داخل `src/routes/` مثل:
  `__root.tsx`, `index.tsx`, `dashboard.tsx`, `dashboard.index.tsx`,
  `dashboard.teachers.tsx`, `dashboard.students.tsx`, `dashboard.recite.$studentId.tsx`,
  `auth.tsx`, `student.$studentId.tsx` (هذه الأسماء مذكورة داخل `routeTree.gen.ts` لكنها غير موجودة ضمن ما أرسلته).
- ملف `src/router.tsx` (يُستورد من `routeTree.gen.ts`).
- مكوّنات الواجهة (React components) وملف `src/main.tsx` أو نقطة الدخول الأساسية.
- `package.json` الأصلي (أنشأت لك نسخة أساسية تقريبية فقط — راجع الاعتماديات).
- `tailwind.config` إن وُجد، وأي مكوّنات shadcn/ui تحت `src/components/ui`.

أسهل طريقة تضمن أن كل شيء يعمل: **صدّر المشروع كاملاً من Lovable مباشرة إلى GitHub**
(زر "GitHub → Connect / Export" داخل محرر Lovable) بدل تجميعه يدويًا من ملفات منفصلة،
ثم استخدم هذا التنظيم فقط كمرجع لمقارنة/فهم البنية.

## خريطة الملفات (من → إلى)

| الملف الذي أرسلته | المكان الصحيح في المشروع |
|---|---|
| `vite_config.ts` | `vite.config.ts` |
| `server.ts` | `src/server.ts` |
| `start.ts` | `src/start.ts` |
| `styles.css` | `src/styles.css` |
| `routeTree_gen.ts` | `src/routeTree.gen.ts` (ملف **مولّد تلقائيًا**، لا يُعدَّل يدويًا) |
| `error-page.ts` | `src/lib/error-page.ts` |
| `error-capture.ts` | `src/lib/error-capture.ts` |
| `lovable-error-reporting.ts` | `src/lib/lovable-error-reporting.ts` |
| `utils.ts` | `src/lib/utils.ts` |
| `xlsx-export.ts` | `src/lib/xlsx-export.ts` |
| `client.ts` | `src/integrations/supabase/client.ts` |
| `client_server.ts` | `src/integrations/supabase/client.server.ts` |
| `types.ts` | `src/integrations/supabase/types.ts` |
| `auth-middleware.ts` | `src/integrations/supabase/auth-middleware.ts` |
| `auth-attacher.ts` | `src/integrations/supabase/auth-attacher.ts` |
| `quran-data.ts` | `src/data/quran-data.ts` |
| `hadith-data.ts` | `src/data/hadith-data.ts` |
| `admin-users_functions.ts` | `src/server/functions/admin-users.functions.ts` |
| `AGENTS.md` | `AGENTS.md` (جذر المشروع) |
| `README.md` (الأصلي) | `src/routes/README.md` (توثيق قواعد التوجيه) |

تحديد هذه المسارات مبني على عبارات `import` الفعلية داخل الملفات نفسها
(مثال: `admin-users_functions.ts` يستورد
`@/integrations/supabase/auth-middleware`، ويحمّل ديناميكيًا
`@/integrations/supabase/client.server`).

## الإعداد

1. انسخ `.env.example` إلى `.env` واملأ القيم:
   ```
   VITE_SUPABASE_URL=...
   VITE_SUPABASE_PUBLISHABLE_KEY=...
   SUPABASE_URL=...
   SUPABASE_PUBLISHABLE_KEY=...
   SUPABASE_SERVICE_ROLE_KEY=...
   ```
   القيم الأولى تُستخدم في المتصفح (client)، والباقي على الخادم فقط
   (`SUPABASE_SERVICE_ROLE_KEY` سري تمامًا — لا تضعه في `.env` مرفوع لأي مكان عام).

2. ثبّت الاعتماديات:
   ```bash
   npm install
   ```

3. شغّل المشروع محليًا:
   ```bash
   npm run dev
   ```

## الرفع على GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<username>/<repo>.git
git push -u origin main
```

تأكد أن `.env` **غير** مرفوع (موجود ضمن `.gitignore`)، وأن `src/routeTree.gen.ts`
يُعاد توليده تلقائيًا عند التشغيل (فكّر بإضافته إلى `.gitignore` إن كان مشروعك
يولّده تلقائيًا عبر TanStack Router plugin، كما هو الحال هنا وفق تعليقات الملف).
